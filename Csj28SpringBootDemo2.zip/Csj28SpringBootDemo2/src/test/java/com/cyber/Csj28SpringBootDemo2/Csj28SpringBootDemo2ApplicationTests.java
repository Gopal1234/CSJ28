package com.cyber.Csj28SpringBootDemo2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Csj28SpringBootDemo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
